example-assetmgmt
================

Snap-in demonstrating UI concepts.