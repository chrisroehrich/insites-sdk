example-parlevels
================

This snap-in is a demonstration of how to extract par level information into an interactive interface. It includes a page allowing staff to find the number of each type of equipment/supply in a location, as well as the corresponding par levels for that location.